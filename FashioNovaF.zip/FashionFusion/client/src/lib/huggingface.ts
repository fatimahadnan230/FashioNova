export interface GenerateImageRequest {
  prompt: string;
  style: string;
  gender: string;
  userId: number;
}

export interface GenerateImageResponse {
  id: number;
  userId: number;
  prompt: string;
  style: string;
  gender: string;
  imageUrl: string;
  isFavorite: boolean;
  isDownloaded: boolean;
  createdAt: string;
}

export const generateImage = async (request: GenerateImageRequest): Promise<GenerateImageResponse> => {
  const response = await fetch("/api/images/generate", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(request),
  });

  if (!response.ok) {
    throw new Error("Failed to generate image");
  }

  return response.json();
};

export const downloadImage = (imageUrl: string, filename: string) => {
  const link = document.createElement('a');
  link.href = imageUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
