# FashioNova - Wasmer.io Deployment Guide

## Quick Deployment Steps

### Prerequisites
- Install Wasmer CLI: `curl https://get.wasmer.io -sSfL | sh`
- Create account at [wasmer.io](https://wasmer.io)
- Login: `wasmer login`

### 1. Build for Wasmer
Run the build script:
```bash
node build-wasmer.js
```

This automatically:
- ✅ Builds the React frontend
- ✅ Copies Wasmer server files to `/dist`
- ✅ Configures WinterJS runtime
- ✅ Sets up proper file structure

### 2. Deploy to Wasmer.io
```bash
cd dist
wasmer deploy . --owner [your-username]
```

Or deploy directly:
```bash
wasmer deploy dist/ --owner [your-username]
```

### 3. Set Environment Variables (Optional)
```bash
wasmer config set HF_API_TOKEN your_hugging_face_token
```

## What's Configured for Wasmer

### ✅ WinterJS Runtime
- **Server**: Optimized JavaScript server using WinterJS
- **Performance**: Fast startup and low memory usage
- **Compatibility**: Web standard APIs (fetch, Response, etc.)

### ✅ File Structure
```
dist/
├── wasmer.toml          # Wasmer configuration
├── server.js            # WinterJS server
├── storage.js           # In-memory data storage
├── package.json         # Runtime dependencies
└── public/              # Static React build files
    ├── index.html
    ├── assets/
    └── ...
```

### ✅ API Endpoints
All working on Wasmer:
- `POST /api/auth/login` - User authentication
- `POST /api/images/generate` - AI image generation
- `GET /api/images/user/:id` - Get user images
- `GET /api/images/favorites/:id` - Get favorites
- `GET /api/images/downloads/:id` - Get downloads
- `PATCH /api/images/:id/favorite` - Toggle favorite
- `PATCH /api/images/:id/download` - Mark downloaded

### ✅ Static File Serving
- React SPA with proper routing
- Optimized asset delivery
- Automatic fallback to index.html

## Configuration Details

### wasmer.toml
```toml
[package]
name = "fashionova"
version = "1.0.0"
description = "AI-powered fashion design generator"

[dependencies]
"wasmer/winterjs" = "1.3.0"

[fs]
"/app" = "dist"

[[command]]
name = "start"
module = "wasmer/winterjs:winterjs"
runner = "https://webc.org/runner/winterjs"
```

### Features on Wasmer

✅ **Lightning Fast**: WinterJS runtime for optimal performance
✅ **Zero Config**: Everything pre-configured
✅ **Global CDN**: Automatic edge deployment
✅ **HTTPS**: SSL certificates included
✅ **Custom Domains**: Available on paid plans
✅ **Environment Variables**: Secure config management

## Cost & Scaling

- **Free Tier**: Perfect for testing and small projects
- **Automatic Scaling**: Handles traffic spikes
- **Global Edge**: Deployed worldwide
- **No Cold Starts**: Instant response times

## Development vs Production

### Development (Current)
- In-memory storage (resets on restart)
- Embedded API key (for testing)
- Single instance

### Production Upgrades (Optional)
- External database (Redis, PostgreSQL)
- Proper API key management
- CDN for image storage
- User authentication service

## Deployment URL

After deployment, your app will be available at:
`https://[your-username]-fashionova.wasmer.app`

## Troubleshooting

### Build Issues
```bash
# Clean and rebuild
rm -rf dist/
node build-wasmer.js
```

### Deployment Issues
```bash
# Check Wasmer status
wasmer --version

# Re-login if needed
wasmer login
```

### Runtime Issues
- Check logs in Wasmer dashboard
- Verify environment variables
- Ensure HF API key is valid

## Benefits of Wasmer.io

🚀 **Performance**: WinterJS is faster than Node.js for web servers
🌍 **Global**: Automatic edge deployment worldwide  
🔒 **Secure**: Built-in security and isolation
📊 **Analytics**: Built-in monitoring and logs
💰 **Cost-Effective**: Pay only for what you use
🛠️ **DevOps-Free**: No server management needed

Your FashioNova app is now ready for production on Wasmer.io!