import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { downloadImage } from "@/lib/huggingface";
import ImageGrid from "./image-grid";
import { Heart } from "lucide-react";
import type { GeneratedImage } from "@shared/schema";

interface FavoritesGalleryProps {
  userId: number;
}

export default function FavoritesGallery({ userId }: FavoritesGalleryProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: favoriteImages = [], isLoading } = useQuery<GeneratedImage[]>({
    queryKey: ["/api/images/favorites", userId.toString()],
  });

  const downloadMutation = useMutation({
    mutationFn: async (imageId: number) => {
      const response = await apiRequest("PATCH", `/api/images/${imageId}/download`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/images"] });
      toast({
        title: "Download recorded!",
        description: "Image added to download history",
      });
    },
  });

  const unfavoriteMutation = useMutation({
    mutationFn: async (imageId: number) => {
      const response = await apiRequest("PATCH", `/api/images/${imageId}/favorite`, {
        isFavorite: false,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/images"] });
      toast({
        title: "Removed from favorites",
        description: "Image no longer in favorites",
      });
    },
  });

  const handleFavorite = (image: GeneratedImage) => {
    unfavoriteMutation.mutate(image.id);
  };

  const handleDownload = (image: GeneratedImage) => {
    const filename = `fashion-favorite-${image.id}-${Date.now()}.png`;
    downloadImage(image.imageUrl, filename);
    downloadMutation.mutate(image.id);
  };

  const handleShare = (image: GeneratedImage) => {
    if (navigator.share) {
      navigator.share({
        title: "My Favorite AI Fashion Design",
        text: image.prompt,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copied!",
        description: "Share link copied to clipboard",
      });
    }
  };

  if (isLoading) {
    return (
      <Card className="shadow-lg">
        <CardContent className="p-6">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded mb-6"></div>
            <div className="masonry">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="masonry-item">
                  <div className="bg-gray-200 rounded-xl h-48 mb-4"></div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg">
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-6 text-gray-800 flex items-center">
          <Heart className="mr-3 text-red-500" />
          Your Favorite Designs
        </h2>
        
        <ImageGrid 
          images={favoriteImages}
          onFavorite={handleFavorite}
          onDownload={handleDownload}
          onShare={handleShare}
        />
      </CardContent>
    </Card>
  );
}
