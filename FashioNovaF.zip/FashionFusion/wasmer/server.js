// FashioNova Server for Wasmer.io WinterJS
import { serve } from '@winterjs/http';
import { storage } from './storage.js';

// Inline schema validation (simplified for WinterJS)
const validateUser = (data) => {
  if (!data.email || !data.name) throw new Error('Email and name required');
  return { email: data.email.trim(), name: data.name.trim() };
};

const validateImageGeneration = (data) => {
  if (!data.prompt || !data.userId) throw new Error('Prompt and userId required');
  return data;
};

// Static file serving
const serveStatic = async (pathname) => {
  try {
    const filePath = pathname === '/' ? '/public/index.html' : `/public${pathname}`;
    const file = await Deno.readFile(`.${filePath}`);
    const ext = pathname.split('.').pop();
    const contentType = {
      'html': 'text/html',
      'js': 'application/javascript',
      'css': 'text/css',
      'png': 'image/png',
      'jpg': 'image/jpeg',
      'svg': 'image/svg+xml',
      'ico': 'image/x-icon'
    }[ext] || 'text/plain';
    
    return new Response(file, {
      headers: { 'Content-Type': contentType }
    });
  } catch {
    // Serve index.html for SPA routing
    try {
      const file = await Deno.readFile('./public/index.html');
      return new Response(file, {
        headers: { 'Content-Type': 'text/html' }
      });
    } catch {
      return new Response('Not Found', { status: 404 });
    }
  }
};

const handler = async (request) => {
  const url = new URL(request.url);
  const pathname = url.pathname;
  
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
    'Content-Type': 'application/json',
  };

  // Handle CORS preflight
  if (request.method === 'OPTIONS') {
    return new Response('', { status: 200, headers });
  }

  // API routes
  if (pathname.startsWith('/api/')) {
    try {
      const body = request.method !== 'GET' ? await request.json() : {};

      // Authentication
      if (pathname === '/api/auth/login' && request.method === 'POST') {
        const { email, name } = validateUser(body);
        
        let user = await storage.getUserByEmail(email);
        if (!user) {
          user = await storage.createUser({ email, name });
        }
        
        return new Response(JSON.stringify(user), { headers });
      }

      // Image generation
      if (pathname === '/api/images/generate' && request.method === 'POST') {
        const { prompt, style, gender, userId } = validateImageGeneration(body);
        
        const HF_API_TOKEN = globalThis.Deno?.env?.get?.('HF_API_TOKEN') || 
                            globalThis.Deno?.env?.get?.('HUGGINGFACE_API_TOKEN') || 
                            "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";
        
        const enhancedPrompt = `${prompt}, ${style} style, ${gender} fashion, professional fashion photography, high quality, detailed, beautiful lighting`;

        const response = await fetch("https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-xl-base-1.0", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${HF_API_TOKEN}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            inputs: enhancedPrompt,
            parameters: {
              num_inference_steps: 30,
              guidance_scale: 7.5,
              width: 512,
              height: 768,
            },
          }),
        });

        if (!response.ok) {
          throw new Error(`HuggingFace API error: ${response.statusText}`);
        }

        const imageBuffer = await response.arrayBuffer();
        const base64Image = btoa(String.fromCharCode(...new Uint8Array(imageBuffer)));
        const imageUrl = `data:image/png;base64,${base64Image}`;

        const savedImage = await storage.createGeneratedImage({
          userId,
          prompt,
          style,
          gender,
          imageUrl,
          isFavorite: false,
          isDownloaded: false,
        });

        return new Response(JSON.stringify(savedImage), { headers });
      }

      // Get user images
      if (pathname.match(/^\/api\/images\/user\/\d+$/) && request.method === 'GET') {
        const userId = parseInt(pathname.split('/')[4]);
        const images = await storage.getGeneratedImagesByUserId(userId);
        return new Response(JSON.stringify(images), { headers });
      }

      // Get favorites
      if (pathname.match(/^\/api\/images\/favorites\/\d+$/) && request.method === 'GET') {
        const userId = parseInt(pathname.split('/')[4]);
        const images = await storage.getFavoriteImagesByUserId(userId);
        return new Response(JSON.stringify(images), { headers });
      }

      // Get downloads
      if (pathname.match(/^\/api\/images\/downloads\/\d+$/) && request.method === 'GET') {
        const userId = parseInt(pathname.split('/')[4]);
        const images = await storage.getDownloadedImagesByUserId(userId);
        return new Response(JSON.stringify(images), { headers });
      }

      // Toggle favorite
      if (pathname.match(/^\/api\/images\/\d+\/favorite$/) && request.method === 'PATCH') {
        const imageId = parseInt(pathname.split('/')[3]);
        const { isFavorite } = body;
        
        const updatedImage = await storage.updateImageFavoriteStatus(imageId, isFavorite);
        if (!updatedImage) {
          return new Response(JSON.stringify({ message: "Image not found" }), { 
            status: 404, headers 
          });
        }
        
        return new Response(JSON.stringify(updatedImage), { headers });
      }

      // Mark as downloaded
      if (pathname.match(/^\/api\/images\/\d+\/download$/) && request.method === 'PATCH') {
        const imageId = parseInt(pathname.split('/')[3]);
        
        const updatedImage = await storage.updateImageDownloadStatus(imageId, true);
        if (!updatedImage) {
          return new Response(JSON.stringify({ message: "Image not found" }), { 
            status: 404, headers 
          });
        }
        
        return new Response(JSON.stringify(updatedImage), { headers });
      }

      return new Response(JSON.stringify({ message: "Not found" }), { 
        status: 404, headers 
      });

    } catch (error) {
      console.error("API Error:", error);
      return new Response(JSON.stringify({ message: error.message || "Internal server error" }), { 
        status: 500, headers 
      });
    }
  }

  // Serve static files
  return serveStatic(pathname);
};

// Start server
serve(handler, { port: parseInt(globalThis.Deno?.env?.get?.('PORT') || '8080') });
console.log('FashioNova server running on port 8080');