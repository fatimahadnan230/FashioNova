# FashioNova - Netlify Deployment Guide

## Quick Deployment Steps

### 1. Download the Project
- Download/clone this entire project folder to your local machine

### 2. Deploy to Netlify

**Option A: Direct Upload**
1. Go to [netlify.com](https://netlify.com) and sign up/login
2. Click "Add new site" → "Deploy manually"
3. Drag and drop the entire project folder
4. Netlify will automatically:
   - Detect it's a Vite project
   - Run `npm install`
   - Run `npm run build`
   - Deploy to a live URL

**Option B: Git Integration (Recommended)**
1. Push your code to GitHub/GitLab
2. Connect your repository to Netlify
3. Netlify will auto-deploy on every push

### 3. Set Environment Variables (Optional)
In Netlify dashboard → Site settings → Environment variables:
- `HF_API_TOKEN`: Your Hugging Face API token (already included as fallback)
- `HUGGINGFACE_API_TOKEN`: Alternative name for the same token

### 4. Build Configuration
The project includes `netlify.toml` with these settings:
```toml
[build]
  publish = "dist/public"
  command = "npm run build"

[build.environment]
  NODE_VERSION = "20"

[[redirects]]
  from = "/api/*"
  to = "/.netlify/functions/api/:splat"
  status = 200

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

## What's Included for Netlify

✅ **Serverless Functions**: API routes converted to Netlify Functions
✅ **Static File Serving**: React app builds to static files
✅ **SPA Routing**: Proper redirects for client-side routing
✅ **CORS Headers**: Configured for cross-origin requests
✅ **Environment Variables**: Support for API keys
✅ **Build Optimization**: Automatic bundling and minification

## Features That Work on Netlify

✅ **User Authentication**: Email/name based login
✅ **AI Image Generation**: Via Hugging Face API
✅ **Image Management**: Favorites, downloads, sharing
✅ **Responsive Design**: Works on all devices
✅ **Pastel Theme**: Beautiful pink/blue/lavender design
✅ **Real-time Updates**: State management with React Query

## Important Notes

- **Data Storage**: Uses in-memory storage (resets on function restart)
- **API Limits**: Hugging Face API has rate limits for free accounts
- **Image Storage**: Images are base64 encoded (temporary storage)
- **No Database Required**: Everything works without external databases

## Upgrade Path (Optional)

For production use, consider:
- External database (Neon, Supabase, etc.)
- Image storage service (Cloudinary, AWS S3)
- User authentication service (Auth0, Supabase Auth)

## Cost

- **Netlify**: Free tier includes 100GB bandwidth, 300 build minutes
- **Hugging Face**: Free tier with rate limits
- **Total Cost**: $0 to start!

## Support

The app is designed to work perfectly on Netlify without any modifications. If you encounter issues:
1. Check build logs in Netlify dashboard
2. Verify environment variables are set
3. Ensure all files are uploaded correctly

Your FashioNova app will be live at: `https://[your-site-name].netlify.app`