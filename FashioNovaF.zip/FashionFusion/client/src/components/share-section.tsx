import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import ImageGrid from "./image-grid";
import { Share, Copy, Facebook, Twitter, Instagram } from "lucide-react";
import { SiPinterest } from "react-icons/si";
import type { GeneratedImage } from "@shared/schema";

interface ShareSectionProps {
  userId: number;
}

export default function ShareSection({ userId }: ShareSectionProps) {
  const [shareLink] = useState(`${window.location.origin}/gallery/${userId}`);
  const { toast } = useToast();

  const { data: userImages = [] } = useQuery<GeneratedImage[]>({
    queryKey: ["/api/images/user", userId.toString()],
  });

  const copyShareLink = () => {
    navigator.clipboard.writeText(shareLink);
    toast({
      title: "Link copied!",
      description: "Share link copied to clipboard",
    });
  };

  const shareToSocial = (platform: string) => {
    const text = "Check out my AI-generated fashion designs on FashioNova!";
    const url = shareLink;
    
    let shareUrl = "";
    
    switch (platform) {
      case "facebook":
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
        break;
      case "twitter":
        shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
        break;
      case "pinterest":
        shareUrl = `https://pinterest.com/pin/create/button/?url=${encodeURIComponent(url)}&description=${encodeURIComponent(text)}`;
        break;
      case "instagram":
        // Instagram doesn't support direct web sharing, so copy link instead
        copyShareLink();
        toast({
          title: "Link copied for Instagram!",
          description: "Paste this link in your Instagram bio or story",
        });
        return;
    }
    
    if (shareUrl) {
      window.open(shareUrl, "_blank", "width=600,height=400");
    }
  };

  const handleFavorite = () => {
    toast({
      title: "Feature coming soon!",
      description: "Community features will be available soon",
    });
  };

  const handleDownload = () => {
    toast({
      title: "Feature coming soon!",
      description: "Community downloads will be available soon",
    });
  };

  const handleShare = () => {
    copyShareLink();
  };

  return (
    <Card className="shadow-lg">
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-6 text-gray-800 flex items-center">
          <Share className="mr-3 text-blue-500" />
          Share Your Creations
        </h2>

        {/* Share Options */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6 rounded-xl">
            <h3 className="text-lg font-bold mb-3 flex items-center">
              <Facebook className="mr-2 h-5 w-5" />
              Facebook
            </h3>
            <p className="text-blue-100 mb-4">Share your fashion creations with friends</p>
            <Button
              onClick={() => shareToSocial("facebook")}
              className="bg-white text-blue-600 hover:bg-blue-50"
            >
              Share on Facebook
            </Button>
          </div>

          <div className="bg-gradient-to-r from-pink-500 to-pink-600 text-white p-6 rounded-xl">
            <h3 className="text-lg font-bold mb-3 flex items-center">
              <Instagram className="mr-2 h-5 w-5" />
              Instagram
            </h3>
            <p className="text-pink-100 mb-4">Show off your AI-generated fashion</p>
            <Button
              onClick={() => shareToSocial("instagram")}
              className="bg-white text-pink-600 hover:bg-pink-50"
            >
              Share on Instagram
            </Button>
          </div>

          <div className="bg-gradient-to-r from-blue-400 to-blue-500 text-white p-6 rounded-xl">
            <h3 className="text-lg font-bold mb-3 flex items-center">
              <Twitter className="mr-2 h-5 w-5" />
              Twitter
            </h3>
            <p className="text-blue-100 mb-4">Tweet your fashion inspiration</p>
            <Button
              onClick={() => shareToSocial("twitter")}
              className="bg-white text-blue-500 hover:bg-blue-50"
            >
              Share on Twitter
            </Button>
          </div>

          <div className="bg-gradient-to-r from-red-500 to-red-600 text-white p-6 rounded-xl">
            <h3 className="text-lg font-bold mb-3 flex items-center">
              <SiPinterest className="mr-2 h-5 w-5" />
              Pinterest
            </h3>
            <p className="text-red-100 mb-4">Pin to your fashion boards</p>
            <Button
              onClick={() => shareToSocial("pinterest")}
              className="bg-white text-red-600 hover:bg-red-50"
            >
              Share on Pinterest
            </Button>
          </div>
        </div>

        {/* Share Link */}
        <div className="bg-gray-50 p-6 rounded-xl mb-8">
          <h3 className="text-lg font-bold mb-4 text-gray-800 flex items-center">
            <Share className="mr-2 h-5 w-5" />
            Share via Link
          </h3>
          <div className="flex space-x-2">
            <Input
              value={shareLink}
              readOnly
              className="flex-1 bg-white"
            />
            <Button
              onClick={copyShareLink}
              className="bg-pink-500 text-white hover:bg-pink-600"
            >
              <Copy className="mr-2 h-4 w-4" />
              Copy
            </Button>
          </div>
        </div>

        {/* User Gallery */}
        <div>
          <h3 className="text-xl font-bold mb-6 text-gray-800 flex items-center">
            <span className="mr-2">🎨</span>
            Your Gallery
          </h3>
          <ImageGrid 
            images={userImages}
            onFavorite={handleFavorite}
            onDownload={handleDownload}
            onShare={handleShare}
            showFavoriteAction={false}
          />
        </div>
      </CardContent>
    </Card>
  );
}
