# FashioNova - GitHub Pages Deployment Guide

## Ready for GitHub Pages! 🚀

Your FashioNova app is now configured for easy GitHub deployment with automatic builds and client-side functionality.

## Quick Deployment Steps

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "Initial FashioNova deployment"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/FashioNova.git
git push -u origin main
```

### 2. Enable GitHub Pages
1. Go to your repository settings
2. Click **"Pages"** in sidebar
3. Select **"GitHub Actions"** as source
4. Done! Your app will auto-deploy

### 3. Your Live URL
`https://YOUR_USERNAME.github.io/FashioNova/`

## What's Included

✅ **Automatic GitHub Actions** - Builds and deploys on every push  
✅ **Client-side storage** - Works without a backend server  
✅ **Hugging Face integration** - Direct API calls from browser  
✅ **Full functionality** - Generate, favorites, downloads, sharing  
✅ **Mobile responsive** - Beautiful pastel theme  
✅ **Zero configuration** - Ready to deploy as-is  

## How It Works

**Client-Side Architecture:**
- **Storage**: Uses localStorage for user data and images
- **API Calls**: Direct Hugging Face API integration
- **Authentication**: Simple email-based user system
- **Persistence**: All data saved in browser storage

**GitHub Actions Workflow:**
- Triggers on push to main branch
- Installs dependencies with `npm ci`
- Builds with custom GitHub Pages configuration
- Deploys to GitHub Pages automatically

## Features That Work

- 🎨 **AI Image Generation** - Hugging Face Stable Diffusion
- 👤 **User Authentication** - Email/name registration
- ⭐ **Favorites System** - Mark and manage favorite designs
- 📥 **Download Tracking** - Track downloaded images
- 🔗 **Social Sharing** - Share designs on social media
- 📱 **Mobile Responsive** - Works on all devices
- 🎨 **Pastel Theme** - Beautiful pink/blue/lavender colors

## Repository Structure

```
FashioNova/
├── .github/workflows/deploy.yml  # Auto-deployment
├── build-github.js              # GitHub Pages build
├── client/src/                  # React frontend
├── dist/public/                 # Built files (auto-generated)
└── README.md                    # This guide
```

## Environment Variables (Optional)

GitHub Pages supports environment variables through secrets:

1. Go to **Settings** → **Secrets and variables** → **Actions**
2. Add `HF_API_TOKEN` with your Hugging Face API key
3. The app includes a fallback token, so this is optional

## Cost & Limits

- **GitHub Pages**: Free for public repositories
- **Hugging Face API**: Free tier with rate limits
- **Storage**: Browser localStorage (5-10MB limit)
- **No server costs**: Everything runs client-side

## Troubleshooting

**Build fails?** Check the Actions tab for error details  
**Images not generating?** Verify Hugging Face API is accessible  
**Data loss?** Browser storage clears when cache is cleared  
**Slow loading?** Hugging Face free tier has rate limits  

## Customization

Want to modify the app? Edit files in `client/src/` and push to GitHub. The workflow automatically rebuilds and deploys.

## Support

Your app is ready for production use on GitHub Pages with zero additional configuration needed!