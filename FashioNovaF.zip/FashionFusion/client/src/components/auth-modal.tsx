import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { setCurrentUser } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { Sparkles, X } from "lucide-react";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function AuthModal({ isOpen, onClose, onSuccess }: AuthModalProps) {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email.trim() || !name.trim()) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    try {
      const response = await apiRequest("POST", "/api/auth/login", {
        email: email.trim(),
        name: name.trim(),
      });
      
      const user = await response.json();
      setCurrentUser(user);
      
      toast({
        title: "Welcome to FashioNova!",
        description: "Start creating amazing fashion designs",
      });
      
      onSuccess();
      onClose();
    } catch (error) {
      toast({
        title: "Authentication failed",
        description: "Please try again",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md glass-effect">
        <CardContent className="pt-6 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
          
          <div className="text-center mb-6">
            <div className="flex items-center justify-center mb-4">
              <Sparkles className="h-8 w-8 text-white mr-2" />
              <h1 className="text-2xl font-bold text-white">FashioNova</h1>
            </div>
            <h2 className="text-2xl font-bold text-center text-gray-800 mb-2">Welcome to FashioNova</h2>
            <p className="text-gray-600">Create stunning fashion designs with AI</p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="modal-email" className="text-gray-700 text-sm font-medium">Email</Label>
              <Input
                id="modal-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-400"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="modal-name" className="text-gray-700 text-sm font-medium">Name</Label>
              <Input
                id="modal-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your name"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-400"
                required
              />
            </div>
            
            <Button 
              type="submit" 
              className="w-full gradient-bg text-white py-3 rounded-lg font-medium hover:opacity-90 transition-opacity"
              disabled={isLoading}
            >
              <Sparkles className="mr-2 h-4 w-4" />
              {isLoading ? "Signing in..." : "Start Creating"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
