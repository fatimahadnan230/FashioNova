#!/usr/bin/env node

import { execSync } from 'child_process';
import { readFileSync, writeFileSync, mkdirSync, cpSync, existsSync } from 'fs';

console.log('🚀 Building FashioNova for GitHub Pages...');

// Step 1: Build the React app with correct base path
console.log('📦 Building React frontend for GitHub Pages...');
try {
  // Build with base path for GitHub Pages
  execSync('npx vite build --base=/FashioNova/', { stdio: 'inherit' });
} catch (error) {
  console.error('❌ Frontend build failed:', error.message);
  process.exit(1);
}

// Step 2: Create client-side storage for GitHub Pages
console.log('🔧 Setting up client-side data handling...');

const clientStorageCode = `
// Client-side storage for GitHub Pages deployment
class ClientStorage {
  constructor() {
    this.storageKey = 'fashionova_data';
    this.data = this.loadData();
  }

  loadData() {
    try {
      const stored = localStorage.getItem(this.storageKey);
      return stored ? JSON.parse(stored) : {
        users: [],
        images: [],
        nextUserId: 1,
        nextImageId: 1
      };
    } catch {
      return {
        users: [],
        images: [],
        nextUserId: 1,
        nextImageId: 1
      };
    }
  }

  saveData() {
    localStorage.setItem(this.storageKey, JSON.stringify(this.data));
  }

  // User methods
  async createUser(userData) {
    const user = {
      id: this.data.nextUserId++,
      ...userData,
      createdAt: new Date().toISOString()
    };
    this.data.users.push(user);
    this.saveData();
    return user;
  }

  async findUserByEmail(email) {
    return this.data.users.find(u => u.email === email) || null;
  }

  // Image methods
  async createImage(imageData) {
    const image = {
      id: this.data.nextImageId++,
      ...imageData,
      createdAt: new Date().toISOString(),
      isFavorite: false,
      isDownloaded: false
    };
    this.data.images.push(image);
    this.saveData();
    return image;
  }

  async getUserImages(userId) {
    return this.data.images.filter(img => img.userId === userId);
  }

  async updateImage(imageId, updates) {
    const index = this.data.images.findIndex(img => img.id === imageId);
    if (index !== -1) {
      this.data.images[index] = { ...this.data.images[index], ...updates };
      this.saveData();
      return this.data.images[index];
    }
    return null;
  }
}

// Make storage available globally
window.clientStorage = new ClientStorage();
`;

// Step 3: Update index.html to include client storage
console.log('📄 Updating HTML for client-side deployment...');
let htmlContent = readFileSync('dist/public/index.html', 'utf8');

// Inject client storage script
htmlContent = htmlContent.replace(
  '<head>',
  `<head>
    <script>${clientStorageCode}</script>`
);

writeFileSync('dist/public/index.html', htmlContent);

// Step 4: Create client-side API simulation
console.log('🌐 Creating client-side API simulation...');

const apiSimulationCode = `
// Client-side API simulation for GitHub Pages
window.apiRequest = async function(endpoint, options = {}) {
  const storage = window.clientStorage;
  const { method = 'GET', body } = options;
  
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 100));
  
  try {
    if (endpoint === '/api/auth/login' && method === 'POST') {
      const userData = JSON.parse(body);
      let user = await storage.findUserByEmail(userData.email);
      if (!user) {
        user = await storage.createUser(userData);
      }
      return user;
    }
    
    if (endpoint.startsWith('/api/images/user/') && method === 'GET') {
      const userId = parseInt(endpoint.split('/').pop());
      return await storage.getUserImages(userId);
    }
    
    if (endpoint === '/api/images/generate' && method === 'POST') {
      const requestData = JSON.parse(body);
      
      // Call Hugging Face API directly from client
      const hfResponse = await fetch('https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-xl-base-1.0', {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer 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',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          inputs: \`high-quality fashion design, \${requestData.prompt}, professional fashion photography, studio lighting, elegant, sophisticated, trending on fashion magazines\`,
          parameters: {
            guidance_scale: 7.5,
            num_inference_steps: 50
          }
        })
      });
      
      if (!hfResponse.ok) throw new Error('Failed to generate image');
      
      const blob = await hfResponse.blob();
      const base64 = await new Promise(resolve => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.readAsDataURL(blob);
      });
      
      // Save to client storage
      const image = await storage.createImage({
        userId: requestData.userId,
        prompt: requestData.prompt,
        style: requestData.style || 'elegant',
        gender: requestData.gender || 'unisex',
        imageData: base64
      });
      
      return image;
    }
    
    if (endpoint.startsWith('/api/images/') && method === 'PATCH') {
      const imageId = parseInt(endpoint.split('/')[3]);
      const updates = JSON.parse(body);
      return await storage.updateImage(imageId, updates);
    }
    
    throw new Error(\`Unsupported endpoint: \${endpoint}\`);
  } catch (error) {
    throw error;
  }
};
`;

// Inject API simulation into HTML
htmlContent = readFileSync('dist/public/index.html', 'utf8');
htmlContent = htmlContent.replace(
  '</head>',
  `  <script>${apiSimulationCode}</script>
  </head>`
);

writeFileSync('dist/public/index.html', htmlContent);

console.log('✅ GitHub Pages build complete!');
console.log('📁 Files ready in dist/public/');
console.log('🚀 Push to GitHub and enable Pages in repository settings');
console.log('🌐 Your app will be live at: https://[username].github.io/FashioNova/');