// In-memory storage for Wasmer.io deployment
class MemStorage {
  constructor() {
    this.users = new Map();
    this.generatedImages = new Map();
    this.currentUserId = 1;
    this.currentImageId = 1;
  }

  async getUser(id) {
    return this.users.get(id);
  }

  async getUserByEmail(email) {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser) {
    const id = this.currentUserId++;
    const user = { 
      ...insertUser, 
      id, 
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  async createGeneratedImage(insertImage) {
    const id = this.currentImageId++;
    const image = { 
      ...insertImage, 
      id, 
      createdAt: new Date(),
      isFavorite: insertImage.isFavorite ?? false,
      isDownloaded: insertImage.isDownloaded ?? false
    };
    this.generatedImages.set(id, image);
    return image;
  }

  async getGeneratedImagesByUserId(userId) {
    return Array.from(this.generatedImages.values())
      .filter(image => image.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getFavoriteImagesByUserId(userId) {
    return Array.from(this.generatedImages.values())
      .filter(image => image.userId === userId && image.isFavorite)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getDownloadedImagesByUserId(userId) {
    return Array.from(this.generatedImages.values())
      .filter(image => image.userId === userId && image.isDownloaded)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async updateImageFavoriteStatus(imageId, isFavorite) {
    const image = this.generatedImages.get(imageId);
    if (image) {
      const updatedImage = { ...image, isFavorite };
      this.generatedImages.set(imageId, updatedImage);
      return updatedImage;
    }
    return undefined;
  }

  async updateImageDownloadStatus(imageId, isDownloaded) {
    const image = this.generatedImages.get(imageId);
    if (image) {
      const updatedImage = { ...image, isDownloaded };
      this.generatedImages.set(imageId, updatedImage);
      return updatedImage;
    }
    return undefined;
  }
}

export const storage = new MemStorage();