import { users, generatedImages, type User, type InsertUser, type GeneratedImage, type InsertGeneratedImage } from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Generated images methods
  createGeneratedImage(image: InsertGeneratedImage): Promise<GeneratedImage>;
  getGeneratedImagesByUserId(userId: number): Promise<GeneratedImage[]>;
  getFavoriteImagesByUserId(userId: number): Promise<GeneratedImage[]>;
  getDownloadedImagesByUserId(userId: number): Promise<GeneratedImage[]>;
  updateImageFavoriteStatus(imageId: number, isFavorite: boolean): Promise<GeneratedImage | undefined>;
  updateImageDownloadStatus(imageId: number, isDownloaded: boolean): Promise<GeneratedImage | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private generatedImages: Map<number, GeneratedImage>;
  private currentUserId: number;
  private currentImageId: number;

  constructor() {
    this.users = new Map();
    this.generatedImages = new Map();
    this.currentUserId = 1;
    this.currentImageId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  async createGeneratedImage(insertImage: InsertGeneratedImage): Promise<GeneratedImage> {
    const id = this.currentImageId++;
    const image: GeneratedImage = { 
      ...insertImage, 
      id, 
      createdAt: new Date(),
      isFavorite: insertImage.isFavorite ?? false,
      isDownloaded: insertImage.isDownloaded ?? false
    };
    this.generatedImages.set(id, image);
    return image;
  }

  async getGeneratedImagesByUserId(userId: number): Promise<GeneratedImage[]> {
    return Array.from(this.generatedImages.values())
      .filter(image => image.userId === userId)
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }

  async getFavoriteImagesByUserId(userId: number): Promise<GeneratedImage[]> {
    return Array.from(this.generatedImages.values())
      .filter(image => image.userId === userId && image.isFavorite)
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }

  async getDownloadedImagesByUserId(userId: number): Promise<GeneratedImage[]> {
    return Array.from(this.generatedImages.values())
      .filter(image => image.userId === userId && image.isDownloaded)
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }

  async updateImageFavoriteStatus(imageId: number, isFavorite: boolean): Promise<GeneratedImage | undefined> {
    const image = this.generatedImages.get(imageId);
    if (image) {
      const updatedImage = { ...image, isFavorite };
      this.generatedImages.set(imageId, updatedImage);
      return updatedImage;
    }
    return undefined;
  }

  async updateImageDownloadStatus(imageId: number, isDownloaded: boolean): Promise<GeneratedImage | undefined> {
    const image = this.generatedImages.get(imageId);
    if (image) {
      const updatedImage = { ...image, isDownloaded };
      this.generatedImages.set(imageId, updatedImage);
      return updatedImage;
    }
    return undefined;
  }
}

export const storage = new MemStorage();
