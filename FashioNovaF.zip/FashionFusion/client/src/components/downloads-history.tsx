import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { downloadImage } from "@/lib/huggingface";
import { Download, RotateCcw } from "lucide-react";
import type { GeneratedImage } from "@shared/schema";

interface DownloadsHistoryProps {
  userId: number;
}

export default function DownloadsHistory({ userId }: DownloadsHistoryProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: downloadedImages = [], isLoading } = useQuery<GeneratedImage[]>({
    queryKey: ["/api/images/downloads", userId.toString()],
  });

  const handleRedownload = (image: GeneratedImage) => {
    const filename = `fashion-redownload-${image.id}-${Date.now()}.png`;
    downloadImage(image.imageUrl, filename);
    toast({
      title: "Re-download started!",
      description: "Image download initiated",
    });
  };

  const handleDownloadAll = () => {
    if (downloadedImages.length === 0) {
      toast({
        title: "No images to download",
        description: "Your download history is empty",
        variant: "destructive",
      });
      return;
    }

    downloadedImages.forEach((image, index) => {
      setTimeout(() => {
        const filename = `fashion-bulk-${image.id}-${Date.now()}.png`;
        downloadImage(image.imageUrl, filename);
      }, index * 1000); // Stagger downloads to avoid overwhelming the browser
    });

    toast({
      title: "Bulk download started!",
      description: `Downloading ${downloadedImages.length} images`,
    });
  };

  if (isLoading) {
    return (
      <Card className="shadow-lg">
        <CardContent className="p-6">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded mb-6"></div>
            <div className="h-12 bg-gray-200 rounded mb-6"></div>
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-16 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg">
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-6 text-gray-800 flex items-center">
          <Download className="mr-3 text-green-500" />
          Download History
        </h2>
        
        {downloadedImages.length > 0 && (
          <div className="mb-6">
            <Button
              onClick={handleDownloadAll}
              className="gradient-bg text-white hover:opacity-90"
            >
              <Download className="mr-2 h-4 w-4" />
              Download All as ZIP
            </Button>
          </div>
        )}

        {downloadedImages.length === 0 ? (
          <div className="text-center py-16 text-gray-500">
            <Download className="mx-auto h-16 w-16 mb-4 opacity-30" />
            <p className="text-lg">No downloads yet</p>
            <p className="text-sm">Download some designs to see them here!</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full table-auto">
              <thead>
                <tr className="bg-gray-50">
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Image</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Prompt</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Downloaded</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Action</th>
                </tr>
              </thead>
              <tbody>
                {downloadedImages.map((image) => (
                  <tr key={image.id} className="border-b hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <img 
                        src={image.imageUrl} 
                        alt={image.prompt} 
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                    </td>
                    <td className="py-3 px-4">
                      <p className="text-sm text-gray-800 line-clamp-2">
                        {image.prompt}
                      </p>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-sm text-gray-600">
                        {new Date(image.createdAt!).toLocaleDateString()}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <Button
                        onClick={() => handleRedownload(image)}
                        variant="ghost"
                        size="sm"
                        className="text-green-500 hover:text-green-600"
                      >
                        <RotateCcw className="mr-1 h-4 w-4" />
                        Re-download
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
