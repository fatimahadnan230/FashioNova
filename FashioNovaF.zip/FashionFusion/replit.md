# FashioNova - AI-Powered Fashion Design Generator

## Overview

FashioNova is a full-stack web application that enables users to generate AI-powered fashion designs using the Hugging Face Stable Diffusion model. The application features a modern React frontend with shadcn/ui components and an Express.js backend with in-memory storage for development, ready for easy Netlify deployment.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **Forms**: React Hook Form with Zod validation via @hookform/resolvers

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Style**: RESTful API endpoints
- **Development**: tsx for TypeScript execution in development
- **Production Build**: esbuild for server bundling

### Data Storage Solutions
- **Database**: PostgreSQL via Neon Database (@neondatabase/serverless)
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for migrations and schema changes
- **Validation**: Zod schemas with drizzle-zod integration

### Authentication and Authorization
- **Approach**: Simple email-based authentication without passwords
- **Storage**: localStorage for client-side user persistence
- **Session Management**: Basic user identification via email lookup

## Key Components

### Database Schema
- **Users Table**: Stores user information (id, email, name, created_at)
- **Generated Images Table**: Stores image metadata including prompts, styles, favorites, and download status
- **Relationships**: Foreign key relationship between users and their generated images

### API Endpoints
- `POST /api/auth/login` - User authentication/registration
- `POST /api/images/generate` - AI image generation via Hugging Face API
- Image management endpoints for favorites and downloads (referenced in components)

### Frontend Components
- **ImageGenerator**: Main component for creating AI fashion designs
- **ImageGrid**: Reusable component for displaying image collections
- **FavoritesGallery**: Component for managing favorite images
- **DownloadsHistory**: Component for tracking downloaded images
- **ShareSection**: Social sharing functionality
- **AuthModal/AuthPage**: User authentication interface

### External Service Integration
- **Hugging Face API**: Stable Diffusion XL model for image generation
- **Image Processing**: Base64 to Blob conversion for downloadable images
- **Social Sharing**: Integration with major social platforms

## Data Flow

1. **User Authentication**: Users provide email and name for simple registration/login
2. **Image Generation**: Users input prompts with style and gender preferences
3. **AI Processing**: Backend calls Hugging Face API with enhanced prompts
4. **Image Storage**: Generated images are stored as base64 data and converted to downloadable formats
5. **User Actions**: Users can favorite, download, and share generated images
6. **Data Persistence**: All user actions and image metadata are stored in PostgreSQL

## External Dependencies

### AI Services
- **Hugging Face Inference API**: Stable Diffusion XL Base 1.0 model for image generation
- **API Authentication**: Uses Hugging Face API tokens for authenticated requests

### Database
- **Neon Database**: Serverless PostgreSQL hosting
- **Connection**: Environment variable-based connection string

### UI Components
- **Radix UI**: Comprehensive component library for accessibility
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library for consistent iconography

### Development Tools
- **Replit Integration**: Custom plugins for development environment
- **Error Handling**: Runtime error overlay for development debugging

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds optimized React application to `dist/public`
- **Backend**: esbuild bundles Express server to `dist/index.js`
- **Assets**: Static files served from build output directory

### Environment Configuration
- **Development**: tsx with hot reloading and Vite middleware
- **Production**: Node.js serves bundled application with static file serving
- **Database**: Environment variable configuration for database connections

### File Structure
- **Monorepo Layout**: Shared schema between client and server in `/shared` directory
- **Path Aliases**: TypeScript path mapping for clean imports
- **Asset Management**: Centralized asset handling via Vite configuration

### Memory Storage Fallback
The application includes a memory storage implementation as a fallback when database connections are unavailable, ensuring development continuity.