import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { getCurrentUser, clearCurrentUser } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { Sparkles, LogOut, User } from "lucide-react";
import ImageGenerator from "@/components/image-generator";
import FavoritesGallery from "@/components/favorites-gallery";
import DownloadsHistory from "@/components/downloads-history";
import ShareSection from "@/components/share-section";

type Tab = "generate" | "favorites" | "downloads" | "share";

export default function Home() {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<Tab>("generate");
  const { toast } = useToast();
  const user = getCurrentUser();

  if (!user) {
    setLocation("/auth");
    return null;
  }

  const handleLogout = () => {
    clearCurrentUser();
    toast({
      title: "Logged out",
      description: "See you soon!",
    });
    setLocation("/auth");
  };

  const tabs = [
    { id: "generate" as Tab, label: "Generate", icon: Sparkles },
    { id: "favorites" as Tab, label: "Favorites", icon: "heart" },
    { id: "downloads" as Tab, label: "Downloads", icon: "download" },
    { id: "share" as Tab, label: "Share", icon: "share" },
  ];

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="gradient-bg shadow-lg sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <Sparkles className="text-white text-2xl" />
              <h1 className="text-2xl font-bold text-white">FashioNova</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-white">
                <User className="h-4 w-4" />
                <span>Welcome, {user.name}!</span>
              </div>
              <Button
                onClick={handleLogout}
                variant="outline"
                size="sm"
                className="bg-white text-purple-600 hover:bg-white/90"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Tab Navigation */}
        <div className="flex flex-wrap justify-center mb-8 bg-white rounded-2xl p-2 shadow-lg">
          {tabs.map((tab) => (
            <Button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              variant="ghost"
              className={`px-6 py-3 rounded-xl font-medium transition-all mx-1 mb-2 ${
                activeTab === tab.id
                  ? "tab-active text-white"
                  : "text-gray-600 hover:text-gray-800"
              }`}
            >
              {tab.id === "generate" && <Sparkles className="h-4 w-4 mr-2" />}
              {tab.id === "favorites" && <span className="mr-2">♥</span>}
              {tab.id === "downloads" && <span className="mr-2">⬇</span>}
              {tab.id === "share" && <span className="mr-2">↗</span>}
              {tab.label}
            </Button>
          ))}
        </div>

        {/* Tab Content */}
        {activeTab === "generate" && <ImageGenerator userId={user.id} />}
        {activeTab === "favorites" && <FavoritesGallery userId={user.id} />}
        {activeTab === "downloads" && <DownloadsHistory userId={user.id} />}
        {activeTab === "share" && <ShareSection userId={user.id} />}
      </main>
    </div>
  );
}
