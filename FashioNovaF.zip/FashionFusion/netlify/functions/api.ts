import type { Handler } from '@netlify/functions';
import { storage } from '../../server/storage';
import { insertUserSchema, insertGeneratedImageSchema } from '../../shared/schema';

export const handler: Handler = async (event) => {
  const path = event.path.replace('/.netlify/functions/api', '');
  
  // Set CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
    'Content-Type': 'application/json',
  };

  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    // Parse body for POST/PATCH requests
    const body = event.body ? JSON.parse(event.body) : {};

    // Authentication routes
    if (path === '/auth/login' && event.httpMethod === 'POST') {
      const { email, name } = insertUserSchema.parse(body);
      
      let user = await storage.getUserByEmail(email);
      if (!user) {
        user = await storage.createUser({ email, name });
      }
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(user),
      };
    }

    // Image generation route
    if (path === '/images/generate' && event.httpMethod === 'POST') {
      const HF_API_TOKEN = process.env.HF_API_TOKEN || process.env.HUGGINGFACE_API_TOKEN || "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";
      const HF_API_URL = "https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-xl-base-1.0";
      
      const { prompt, style, gender, userId } = body;
      
      if (!prompt || !userId) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ message: "Prompt and userId are required" }),
        };
      }

      const enhancedPrompt = `${prompt}, ${style} style, ${gender} fashion, professional fashion photography, high quality, detailed, beautiful lighting`;

      const response = await fetch(HF_API_URL, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${HF_API_TOKEN}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          inputs: enhancedPrompt,
          parameters: {
            num_inference_steps: 30,
            guidance_scale: 7.5,
            width: 512,
            height: 768,
          },
        }),
      });

      if (!response.ok) {
        throw new Error(`HuggingFace API error: ${response.statusText}`);
      }

      const imageBuffer = await response.arrayBuffer();
      const base64Image = Buffer.from(imageBuffer).toString('base64');
      const imageUrl = `data:image/png;base64,${base64Image}`;

      const savedImage = await storage.createGeneratedImage({
        userId,
        prompt,
        style,
        gender,
        imageUrl,
        isFavorite: false,
        isDownloaded: false,
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(savedImage),
      };
    }

    // Get user images
    if (path.startsWith('/images/user/') && event.httpMethod === 'GET') {
      const userId = parseInt(path.split('/')[3]);
      const images = await storage.getGeneratedImagesByUserId(userId);
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(images),
      };
    }

    // Get favorites
    if (path.startsWith('/images/favorites/') && event.httpMethod === 'GET') {
      const userId = parseInt(path.split('/')[3]);
      const images = await storage.getFavoriteImagesByUserId(userId);
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(images),
      };
    }

    // Get downloads
    if (path.startsWith('/images/downloads/') && event.httpMethod === 'GET') {
      const userId = parseInt(path.split('/')[3]);
      const images = await storage.getDownloadedImagesByUserId(userId);
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(images),
      };
    }

    // Toggle favorite
    if (path.match(/\/images\/\d+\/favorite/) && event.httpMethod === 'PATCH') {
      const imageId = parseInt(path.split('/')[2]);
      const { isFavorite } = body;
      
      const updatedImage = await storage.updateImageFavoriteStatus(imageId, isFavorite);
      if (!updatedImage) {
        return {
          statusCode: 404,
          headers,
          body: JSON.stringify({ message: "Image not found" }),
        };
      }
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(updatedImage),
      };
    }

    // Mark as downloaded
    if (path.match(/\/images\/\d+\/download/) && event.httpMethod === 'PATCH') {
      const imageId = parseInt(path.split('/')[2]);
      
      const updatedImage = await storage.updateImageDownloadStatus(imageId, true);
      if (!updatedImage) {
        return {
          statusCode: 404,
          headers,
          body: JSON.stringify({ message: "Image not found" }),
        };
      }
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(updatedImage),
      };
    }

    return {
      statusCode: 404,
      headers,
      body: JSON.stringify({ message: "Not found" }),
    };

  } catch (error) {
    console.error("API Error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: "Internal server error" }),
    };
  }
};