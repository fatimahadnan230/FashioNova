import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { setCurrentUser } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { Sparkles } from "lucide-react";

export default function AuthPage() {
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email.trim() || !name.trim()) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    try {
      const response = await apiRequest("POST", "/api/auth/login", {
        email: email.trim(),
        name: name.trim(),
      });
      
      const user = await response.json();
      setCurrentUser(user);
      
      toast({
        title: "Welcome to FashioNova!",
        description: "Start creating amazing fashion designs",
      });
      
      setLocation("/");
    } catch (error) {
      toast({
        title: "Authentication failed",
        description: "Please try again",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen gradient-bg flex items-center justify-center p-4">
      <Card className="w-full max-w-md glass-effect">
        <CardContent className="pt-6">
          <div className="text-center mb-6">
            <div className="flex items-center justify-center mb-4">
              <Sparkles className="h-8 w-8 text-white mr-2" />
              <h1 className="text-2xl font-bold text-white">FashioNova</h1>
            </div>
            <p className="text-white/80">Create stunning fashion designs with AI</p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="email" className="text-white">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                className="bg-white/90"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="name" className="text-white">Name</Label>
              <Input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your name"
                className="bg-white/90"
                required
              />
            </div>
            
            <Button 
              type="submit" 
              className="w-full bg-white text-purple-600 hover:bg-white/90"
              disabled={isLoading}
            >
              {isLoading ? "Signing in..." : "Start Creating"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
