#!/usr/bin/env node

import { execSync } from 'child_process';
import { readFileSync, writeFileSync, mkdirSync, cpSync, existsSync, rmSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

console.log('🚀 Building FashioNova for Wasmer.io web upload...');

// Step 1: Clean previous build
if (existsSync('wasmer-build')) {
  rmSync('wasmer-build', { recursive: true });
}
mkdirSync('wasmer-build', { recursive: true });

// Step 2: Build the React app
console.log('📦 Building React frontend...');
try {
  execSync('npm run build', { stdio: 'inherit' });
} catch (error) {
  console.error('❌ Frontend build failed:', error.message);
  process.exit(1);
}

// Step 3: Copy built frontend to wasmer-build/public
console.log('📁 Setting up file structure for Wasmer...');
cpSync('dist/public', 'wasmer-build/public', { recursive: true });

// Step 4: Copy Wasmer server files
console.log('🔧 Setting up Wasmer server...');
cpSync('wasmer/server.js', 'wasmer-build/server.js');
cpSync('wasmer/storage.js', 'wasmer-build/storage.js');

// Step 5: Copy wasmer.toml to root
cpSync('wasmer.toml', 'wasmer-build/wasmer.toml');

// Step 6: Create package.json for Wasmer
console.log('📄 Creating Wasmer package configuration...');
const wasmerPackage = {
  "name": "fashionova",
  "version": "1.0.0",
  "type": "module",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  }
};

writeFileSync('wasmer-build/package.json', JSON.stringify(wasmerPackage, null, 2));

console.log('✅ Wasmer.io build complete!');
console.log('📦 Your Wasmer-ready app is in the /wasmer-build directory');
console.log('🌐 Upload the entire wasmer-build folder to Wasmer.io website');
console.log('📁 Folder structure:');
console.log('   wasmer-build/');
console.log('   ├── wasmer.toml');
console.log('   ├── server.js');
console.log('   ├── storage.js');
console.log('   ├── package.json');
console.log('   └── public/');
console.log('       ├── index.html');
console.log('       └── assets/...');