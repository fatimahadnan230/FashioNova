# FashioNova 🎨

AI-powered fashion design generator with beautiful pastel theming and full client-side functionality.

## ✨ Features

- 🤖 **AI Fashion Generation** - Create unique fashion designs using Hugging Face Stable Diffusion
- 👤 **Simple Authentication** - Email-based user registration (no passwords needed)
- ⭐ **Favorites System** - Save and manage your favorite designs
- 📥 **Download Tracking** - Keep track of downloaded images
- 🔗 **Social Sharing** - Share your creations on social media
- 🎨 **Pastel Theme** - Beautiful pink, blue, and lavender color scheme
- 📱 **Mobile Responsive** - Works perfectly on all devices

## 🚀 Deploy to GitHub Pages

**Super Easy Deployment - No modifications needed!**

### 1. Create GitHub Repository
1. Create a new repository called `FashioNova`
2. Make sure it's **public** (required for free GitHub Pages)

### 2. Upload Your Code
```bash
git init
git add .
git commit -m "Deploy FashioNova to GitHub Pages"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/FashioNova.git
git push -u origin main
```

### 3. Enable GitHub Pages
1. Go to your repository on GitHub
2. Click **Settings** tab
3. Scroll down to **Pages** section
4. Select **"GitHub Actions"** as the source
5. Done! ✅

Your app will be live at: `https://YOUR_USERNAME.github.io/FashioNova/`

## 🛠 How It Works

**Client-Side Architecture:**
- No backend server required
- Uses browser localStorage for data persistence
- Direct API calls to Hugging Face from the browser
- Automatic GitHub Actions deployment

**Technologies:**
- React + TypeScript for frontend
- Tailwind CSS + shadcn/ui for styling
- Wouter for routing
- TanStack Query for data management
- Hugging Face API for AI image generation

## 🔧 Development

Run locally:
```bash
npm install
npm run dev
```

Build for GitHub Pages:
```bash
node build-github.js
```

## 📝 License

MIT License - Feel free to use and modify!

---

**Ready to deploy?** Just follow the 3 steps above and your FashioNova app will be live on GitHub Pages! 🚀