import { Button } from "@/components/ui/button";
import { Heart, Download, Share } from "lucide-react";
import type { GeneratedImage } from "@shared/schema";

interface ImageGridProps {
  images: GeneratedImage[];
  onFavorite: (image: GeneratedImage) => void;
  onDownload: (image: GeneratedImage) => void;
  onShare: (image: GeneratedImage) => void;
  showFavoriteAction?: boolean;
}

export default function ImageGrid({ 
  images, 
  onFavorite, 
  onDownload, 
  onShare,
  showFavoriteAction = true 
}: ImageGridProps) {
  if (images.length === 0) {
    return (
      <div className="text-center py-16 text-gray-500">
        <div className="text-6xl mb-4 opacity-30">🎨</div>
        <p className="text-lg">No images yet</p>
        <p className="text-sm">Generate some fashion designs to see them here!</p>
      </div>
    );
  }

  return (
    <div className="masonry">
      {images.map((image) => (
        <div key={image.id} className="masonry-item bg-gray-100 rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow">
          <img 
            src={image.imageUrl} 
            alt={image.prompt} 
            className="w-full h-auto"
          />
          <div className="p-3">
            <p className="text-sm text-gray-600 line-clamp-2 mb-2">
              {image.prompt}
            </p>
            <div className="flex justify-between items-center">
              <span className="text-xs text-gray-500">
                {new Date(image.createdAt!).toLocaleDateString()}
              </span>
              <div className="flex space-x-1">
                {showFavoriteAction && (
                  <Button
                    onClick={() => onFavorite(image)}
                    variant="ghost"
                    size="sm"
                    className={`p-1 h-auto ${image.isFavorite ? 'text-red-500' : 'text-gray-400 hover:text-red-500'}`}
                  >
                    <Heart className="h-4 w-4" fill={image.isFavorite ? "currentColor" : "none"} />
                  </Button>
                )}
                <Button
                  onClick={() => onDownload(image)}
                  variant="ghost"
                  size="sm"
                  className="p-1 h-auto text-gray-400 hover:text-green-500"
                >
                  <Download className="h-4 w-4" />
                </Button>
                <Button
                  onClick={() => onShare(image)}
                  variant="ghost"
                  size="sm"
                  className="p-1 h-auto text-gray-400 hover:text-blue-500"
                >
                  <Share className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
