import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { generateImage, downloadImage } from "@/lib/huggingface";
import { apiRequest } from "@/lib/queryClient";
import LoadingOverlay from "./loading-overlay";
import ImageGrid from "./image-grid";
import { Sparkles, Heart, Download, Share, Palette, History } from "lucide-react";
import type { GeneratedImage } from "@shared/schema";

interface ImageGeneratorProps {
  userId: number;
}

export default function ImageGenerator({ userId }: ImageGeneratorProps) {
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState("haute-couture");
  const [gender, setGender] = useState("women");
  const [currentImage, setCurrentImage] = useState<GeneratedImage | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: recentImages = [] } = useQuery<GeneratedImage[]>({
    queryKey: ["/api/images/user", userId.toString()],
  });

  const generateMutation = useMutation({
    mutationFn: () => generateImage({ prompt, style, gender, userId }),
    onSuccess: (data) => {
      setCurrentImage(data);
      queryClient.invalidateQueries({ queryKey: ["/api/images/user"] });
      toast({
        title: "Fashion design generated!",
        description: "Your AI-created fashion is ready",
      });
    },
    onError: () => {
      toast({
        title: "Generation failed",
        description: "Please try again with a different prompt",
        variant: "destructive",
      });
    },
  });

  const favoriteMutation = useMutation({
    mutationFn: async (imageId: number) => {
      const response = await apiRequest("PATCH", `/api/images/${imageId}/favorite`, {
        isFavorite: true,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/images"] });
      toast({
        title: "Added to favorites!",
        description: "Image saved to your favorites",
      });
    },
  });

  const downloadMutation = useMutation({
    mutationFn: async (imageId: number) => {
      const response = await apiRequest("PATCH", `/api/images/${imageId}/download`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/images"] });
      toast({
        title: "Download recorded!",
        description: "Image added to download history",
      });
    },
  });

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) {
      toast({
        title: "Prompt required",
        description: "Please describe your fashion vision",
        variant: "destructive",
      });
      return;
    }
    generateMutation.mutate();
  };

  const handleFavorite = (image: GeneratedImage) => {
    favoriteMutation.mutate(image.id);
  };

  const handleDownload = (image: GeneratedImage) => {
    const filename = `fashion-${image.id}-${Date.now()}.png`;
    downloadImage(image.imageUrl, filename);
    downloadMutation.mutate(image.id);
  };

  const handleShare = (image: GeneratedImage) => {
    if (navigator.share) {
      navigator.share({
        title: "My AI Fashion Design",
        text: image.prompt,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copied!",
        description: "Share link copied to clipboard",
      });
    }
  };

  return (
    <>
      <LoadingOverlay 
        isVisible={generateMutation.isPending} 
        message="Generating your fashion masterpiece..."
      />
      
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Prompt Section */}
        <Card className="shadow-lg">
          <CardContent className="p-6">
            <h2 className="text-2xl font-bold mb-6 text-gray-800 flex items-center">
              <Palette className="mr-3 text-pink-500" />
              Create Fashion
            </h2>
            
            <form onSubmit={handleGenerate} className="space-y-6">
              <div>
                <Label htmlFor="prompt" className="text-sm font-medium mb-3 block">
                  Describe your fashion vision
                </Label>
                <Textarea
                  id="prompt"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={4}
                  className="resize-none"
                  placeholder="elegant evening dress with flowing fabric and intricate embroidery, haute couture style, professional fashion photography..."
                />
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="style">Style</Label>
                  <Select value={style} onValueChange={setStyle}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="haute-couture">Haute Couture</SelectItem>
                      <SelectItem value="streetwear">Streetwear</SelectItem>
                      <SelectItem value="minimalist">Minimalist</SelectItem>
                      <SelectItem value="vintage">Vintage</SelectItem>
                      <SelectItem value="bohemian">Bohemian</SelectItem>
                      <SelectItem value="futuristic">Futuristic</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="gender">Gender</Label>
                  <Select value={gender} onValueChange={setGender}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="women">Women</SelectItem>
                      <SelectItem value="men">Men</SelectItem>
                      <SelectItem value="unisex">Unisex</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button 
                type="submit" 
                className="w-full gradient-bg text-white hover:opacity-90"
                disabled={generateMutation.isPending}
              >
                <Sparkles className="mr-2 h-4 w-4" />
                Generate Fashion
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Preview Section */}
        <Card className="shadow-lg">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold mb-4 text-gray-800 flex items-center">
              <span className="mr-2">🖼️</span>
              Preview
            </h3>
            
            <div className="aspect-square bg-gradient-to-br from-pink-200 to-blue-200 rounded-xl flex items-center justify-center overflow-hidden">
              {currentImage ? (
                <img 
                  src={currentImage.imageUrl} 
                  alt="Generated fashion design" 
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="text-center text-gray-500">
                  <Sparkles className="mx-auto h-16 w-16 mb-4 opacity-50" />
                  <p className="text-lg opacity-75">Your generated fashion will appear here</p>
                </div>
              )}
            </div>
            
            {currentImage && (
              <div className="mt-4 flex space-x-2">
                <Button
                  onClick={() => handleFavorite(currentImage)}
                  variant="outline"
                  className="flex-1 border-red-500 text-red-500 hover:bg-red-50"
                  disabled={favoriteMutation.isPending}
                >
                  <Heart className="mr-2 h-4 w-4" />
                  Favorite
                </Button>
                <Button
                  onClick={() => handleDownload(currentImage)}
                  variant="outline"
                  className="flex-1 border-green-500 text-green-500 hover:bg-green-50"
                  disabled={downloadMutation.isPending}
                >
                  <Download className="mr-2 h-4 w-4" />
                  Download
                </Button>
                <Button
                  onClick={() => handleShare(currentImage)}
                  variant="outline"
                  className="flex-1 border-blue-500 text-blue-500 hover:bg-blue-50"
                >
                  <Share className="mr-2 h-4 w-4" />
                  Share
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Generations */}
      {recentImages.length > 0 && (
        <Card className="mt-8 shadow-lg">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold mb-6 text-gray-800 flex items-center">
              <History className="mr-2 text-purple-500" />
              Recent Generations
            </h3>
            <ImageGrid 
              images={recentImages}
              onFavorite={handleFavorite}
              onDownload={handleDownload}
              onShare={handleShare}
            />
          </CardContent>
        </Card>
      )}
    </>
  );
}
