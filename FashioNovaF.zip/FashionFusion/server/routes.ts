import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertGeneratedImageSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // User authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, name } = insertUserSchema.parse(req.body);
      
      let user = await storage.getUserByEmail(email);
      if (!user) {
        user = await storage.createUser({ email, name });
      }
      
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data" });
    }
  });

  // Generate image route
  app.post("/api/images/generate", async (req, res) => {
    try {
      const HF_API_TOKEN = process.env.HF_API_TOKEN || process.env.HUGGINGFACE_API_TOKEN || "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";
      const HF_API_URL = "https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-xl-base-1.0";
      
      const { prompt, style, gender, userId } = req.body;
      
      if (!prompt || !userId) {
        return res.status(400).json({ message: "Prompt and userId are required" });
      }

      const enhancedPrompt = `${prompt}, ${style} style, ${gender} fashion, professional fashion photography, high quality, detailed, beautiful lighting`;

      const response = await fetch(HF_API_URL, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${HF_API_TOKEN}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          inputs: enhancedPrompt,
          parameters: {
            num_inference_steps: 30,
            guidance_scale: 7.5,
            width: 512,
            height: 768,
          },
        }),
      });

      if (!response.ok) {
        throw new Error(`HuggingFace API error: ${response.statusText}`);
      }

      const imageBuffer = await response.arrayBuffer();
      const base64Image = Buffer.from(imageBuffer).toString('base64');
      const imageUrl = `data:image/png;base64,${base64Image}`;

      const savedImage = await storage.createGeneratedImage({
        userId,
        prompt,
        style,
        gender,
        imageUrl,
        isFavorite: false,
        isDownloaded: false,
      });

      res.json(savedImage);
    } catch (error) {
      console.error("Image generation error:", error);
      res.status(500).json({ message: "Failed to generate image" });
    }
  });

  // Get user's generated images
  app.get("/api/images/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const images = await storage.getGeneratedImagesByUserId(userId);
      res.json(images);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch images" });
    }
  });

  // Get user's favorite images
  app.get("/api/images/favorites/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const images = await storage.getFavoriteImagesByUserId(userId);
      res.json(images);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch favorites" });
    }
  });

  // Get user's downloaded images
  app.get("/api/images/downloads/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const images = await storage.getDownloadedImagesByUserId(userId);
      res.json(images);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch downloads" });
    }
  });

  // Toggle favorite status
  app.patch("/api/images/:imageId/favorite", async (req, res) => {
    try {
      const imageId = parseInt(req.params.imageId);
      const { isFavorite } = req.body;
      
      const updatedImage = await storage.updateImageFavoriteStatus(imageId, isFavorite);
      if (!updatedImage) {
        return res.status(404).json({ message: "Image not found" });
      }
      
      res.json(updatedImage);
    } catch (error) {
      res.status(500).json({ message: "Failed to update favorite status" });
    }
  });

  // Mark image as downloaded
  app.patch("/api/images/:imageId/download", async (req, res) => {
    try {
      const imageId = parseInt(req.params.imageId);
      
      const updatedImage = await storage.updateImageDownloadStatus(imageId, true);
      if (!updatedImage) {
        return res.status(404).json({ message: "Image not found" });
      }
      
      res.json(updatedImage);
    } catch (error) {
      res.status(500).json({ message: "Failed to mark as downloaded" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
